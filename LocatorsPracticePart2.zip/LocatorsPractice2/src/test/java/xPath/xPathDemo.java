package xPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class xPathDemo 
{

	public static void main(String[] args) 
	{
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://www.automationpractice.pl/index.php");
		driver.manage().window().maximize();

		//xPath with single attribute 
		//driver.findElement(By.xpath("//input[@id='search_query_top']")).sendKeys("TShirt");
		
		
		//xPath with multiple attribute
		//driver.findElement(By.xpath("//input[@name='search_query'][@placeholder='Search']")).sendKeys("TShirt");
		
		//xPath with 'And' , 'Or' operator
		//driver.findElement(By.xpath("//input[@name='search_query' and @placeholder='Search']")).sendKeys("Tshirt");
		//driver.findElement(By.xpath("//input[@name='search_query' or @placeholder='xyz']")).sendKeys("Tshirt");
		
		
		//xPath with text() -- inner text
		//driver.findElement(By.xpath("//*[text()='Women']")).click();
		
		/* boolean displaystatus = driver.findElement(By.xpath("//li[text()='No featured products at this time.']")).isDisplayed();
		System.out.println (displaystatus);
		
		String value = driver.findElement(By.xpath("//li[text()='No featured products at this time.']")).getText();
		System.out.println(value); */	
		
		//xPath with contains()
		//driver.findElement(By.xpath("//input[contains(@placeholder,'Sea')]")).sendKeys("Tshirt");
		
		//xPath with starts-with()
		//driver.findElement(By.xpath("//input[starts-with(@placeholder,'Sea')]")).sendKeys("Tshirt");
		
		//chained xPath
		boolean status=driver.findElement(By.xpath("//div[@id='header_logo']/a/img")).isDisplayed();
		System.out.println (status);
	}

}
